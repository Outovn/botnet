TOKEN = "7925501946:AAHe8c6zfFbzm_7kgxbvDp96g-lXpkoxQx8" # Токен бота
CRYPTO = "355888:AAYpaSfO8p5RnS3ed7pE1SX3json4DJGzfX" # Токен CryptoBot
ADMINS = [7490640982] # ID Админов

# Bot Options
bot_name = "outsoft_znoz"
bot_logs = "-1002445146644"
bot_channel_link = "https://t.me/perehodout"
bot_admin = "@outovn"
bot_documentation = "https://t.me/exemse"
bot_works = "https://t.me/perehodout"
bot_reviews = "https://t.me/outovn_rep"


# Price
subscribe_1_day = 1.5
subscribe_7_days = 5
subscribe_14_days = 8
subscribe_30_days = 10
subscribe_365_days = 25
subscribe_infinity_days = 20
